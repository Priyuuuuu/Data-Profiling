# from django.shortcuts import render
# from django.http import HttpResponse
# from django.core.files.storage import FileSystemStorage
# import pandas as pd
# import os
# import json

# # Settings for file upload path
# UPLOAD_DIR = os.path.join(os.path.dirname(__file__), 'uploads')
# os.makedirs(UPLOAD_DIR, exist_ok=True)

# def home(request):
#     return render(request, 'home.html')

# def upload_file(request):
#     if request.method == 'POST' and request.FILES.get('dataset'):
#         dataset = request.FILES['dataset']
#         fs = FileSystemStorage(location=UPLOAD_DIR)
#         file_path = fs.save(dataset.name, dataset)
#         file_full_path = os.path.join(UPLOAD_DIR, file_path)

#         # Process the uploaded file
#         profiling_results = process_dataset(file_full_path)
        
#         # Remove the uploaded file after processing
#         os.remove(file_full_path)
        
#         # Convert profiling_results to a JSON object
#         profiling_json = json.loads(profiling_results)
        
#         return render(request, 'results.html', {'results_json': profiling_json})
#     else:
#         return HttpResponse("No file uploaded.")

# def process_dataset(file_path):
#     """
#     Function to process the dataset and return profiling details, including statistics, in JSON format.
#     """
#     try:
#         # Read the dataset
#         if file_path.endswith('.csv'):
#             df = pd.read_csv(file_path)
#         elif file_path.endswith(('.xls', '.xlsx')):
#             df = pd.read_excel(file_path)
#         else:
#             return json.dumps({"error": "Unsupported file format."})

#         # Profiling results
#         profiling_results = {}

#         # Null value counts
#         profiling_results['null_values'] = df.isnull().sum().astype(int).to_dict()

#         # Data types
#         profiling_results['data_types'] = df.dtypes.astype(str).to_dict()

#         # Basic statistics for numeric columns
#         profiling_results['statistics'] = {}
#         numeric_columns = df.select_dtypes(include='number').columns
#         for column in numeric_columns:
#             profiling_results['statistics'][column] = {
#                 'mean': float(df[column].mean()),
#                 'median': float(df[column].median()),
#                 'mode': float(df[column].mode().iloc[0]) if not df[column].mode().empty else None,
#                 'minimum': float(df[column].min()),
#                 'maximum': float(df[column].max()),
#                 'range': float(df[column].max() - df[column].min()),
#                 'percentile_25': float(df[column].quantile(0.25)),
#                 'percentile_50': float(df[column].quantile(0.50)),  # Same as median
#                 'percentile_75': float(df[column].quantile(0.75)),
#                 'skewness': float(df[column].skew()),
#                 'kurtosis': float(df[column].kurt()),
#             }

#         # Column categories
#         profiling_results['categories'] = {}
#         for column in df.columns:
#             if pd.api.types.is_numeric_dtype(df[column]):
#                 profiling_results['categories'][column] = 'Numerical'
#             elif pd.api.types.is_categorical_dtype(df[column]) or df[column].nunique() < 10:
#                 profiling_results['categories'][column] = 'Categorical'
#             elif pd.api.types.is_datetime64_any_dtype(df[column]):
#                 profiling_results['categories'][column] = 'Datetime'
#             else:
#                 profiling_results['categories'][column] = 'String'

#         # Additional metadata
#         profiling_results['additional_metadata'] = {}
#         for column in df.columns:
#             metadata = {
#                 'unique_values': int(df[column].nunique()),
#                 'most_frequent_value': df[column].mode().iloc[0] if not df[column].mode().empty else None,
#                 'length': float(df[column].apply(lambda x: len(str(x)) if pd.notnull(x) else 0).mean()) if df[column].dtype == 'object' else None,
#                 'typical_pattern': None,  # You could implement regex-based pattern recognition here
#             }
#             profiling_results['additional_metadata'][column] = metadata

#         # Aggregates for numeric columns
#         profiling_results['aggregates'] = {}
#         for column in numeric_columns:
#             profiling_results['aggregates'][column] = {
#                 'count': int(df[column].count()),
#                 'sum': float(df[column].sum()),
#                 'variation': float(df[column].var()),
#                 'standard_deviation': float(df[column].std()),
#             }

#         # Convert profiling_results to JSON
#         profiling_results = json.loads(json.dumps(profiling_results, indent=4, default=str))
#         return json.dumps(profiling_results, indent=4)
#     except Exception as e:
#         return json.dumps({"error": str(e)})



# JSON
# from django.shortcuts import render
# from django.http import HttpResponse
# from django.core.files.storage import FileSystemStorage
# import pandas as pd
# import os
# import json

# # Settings for file upload path
# UPLOAD_DIR = os.path.join(os.path.dirname(__file__), 'uploads')
# os.makedirs(UPLOAD_DIR, exist_ok=True)

# def home(request):
#     return render(request, 'home.html')

# def upload_file(request):
#     if request.method == 'POST' and request.FILES.get('dataset'):
#         dataset = request.FILES['dataset']
#         fs = FileSystemStorage(location=UPLOAD_DIR)
#         file_path = fs.save(dataset.name, dataset)
#         file_full_path = os.path.join(UPLOAD_DIR, file_path)

#         # Process the uploaded file
#         profiling_results = process_dataset(file_full_path)
        
#         # Remove the uploaded file after processing
#         os.remove(file_full_path)
        
#         # Convert profiling_results to a JSON object
#         profiling_json = json.loads(profiling_results)
        
#         return render(request, 'results.html', {'results_json': profiling_json})
#     else:
#         return HttpResponse("No file uploaded.")

# def process_dataset(file_path):
#     """
#     Function to process the dataset and return profiling details, including statistics, in JSON format.
#     """
#     try:
#         # Read the dataset
#         if file_path.endswith('.csv'):
#             df = pd.read_csv(file_path)
#         elif file_path.endswith(('.xls', '.xlsx')):  # Check for excel file formats
#             df = pd.read_excel(file_path)
#         else:
#             return json.dumps({"error": "Unsupported file format."})

#         # Profiling results
#         profiling_results = {}

#         # Process each column's profiling details
#         for column in df.columns:
#             column_info = {}

#             # Null value count and datatype
#             column_info['null_value'] = int(df[column].isnull().sum())
#             column_info['datatype'] = str(df[column].dtype)

#             # Basic statistics for numeric columns (no change)
#             if pd.api.types.is_numeric_dtype(df[column]):
#                 column_info['statistics'] = {
#                     'mean': float(df[column].mean()),
#                     'median': float(df[column].median()),
#                     'mode': float(df[column].mode().iloc[0]) if not df[column].mode().empty else None,
#                     'minimum': float(df[column].min()),
#                     'maximum': float(df[column].max()),
#                     'range': float(df[column].max() - df[column].min()),
#                     'percentile_25': float(df[column].quantile(0.25)),
#                     'percentile_50': float(df[column].quantile(0.50)),  # Same as median
#                     'percentile_75': float(df[column].quantile(0.75)),
#                     'skewness': float(df[column].skew()),
#                     'kurtosis': float(df[column].kurt()),
#                 }

#             # Add additional metadata for each column (no change)
#             profiling_results['additional_metadata'] = {}
#             column_metadata = {
#                 'unique_values': int(df[column].nunique()),
#                 'most_frequent_value': df[column].mode().iloc[0] if not df[column].mode().empty else None,
#                 'length': float(df[column].apply(lambda x: len(str(x)) if pd.notnull(x) else 0).mean()) if df[column].dtype == 'object' else None,
#                 'typical_pattern': None,  # You could implement regex-based pattern recognition here
#             }
#             profiling_results['additional_metadata'][column] = column_metadata
#             # Aggregates for numeric columns (no change)
#             if pd.api.types.is_numeric_dtype(df[column]):
#                 profiling_results['aggregates'] = {}
#                 profiling_results['aggregates'][column] = {
#                     'count': int(df[column].count()),
#                     'sum': float(df[column].sum()),
#                     'variation': float(df[column].var()),
#                     'standard_deviation': float(df[column].std()),
#                 }
#             # Skip boolean columns for statistics
#             if pd.api.types.is_bool_dtype(df[column]):
#                 continue  # Skip boolean columns for further processing

#             # Add column profiling info (null_value + datatype) to profiling_results
#             profiling_results[column] = column_info

#         # Convert profiling_results to JSON
#         profiling_results = json.loads(json.dumps(profiling_results, indent=4, default=str))
#         return json.dumps(profiling_results, indent=4)
#     except Exception as e:
#         return json.dumps({"error": str(e)})




import os
import pandas as pd
import json
from django.shortcuts import render
from django.core.files.storage import FileSystemStorage
from django.http import HttpResponse

# File upload directory
UPLOAD_DIR = 'uploaded_files/'

# Home function to render home.html page
def home(request):
    return render(request, 'home.html')

def process_dataset(file_path):
    # Read the dataset (supports CSV, Excel, etc.)
    file_extension = file_path.split('.')[-1].lower()  # Get file extension
    
    if file_extension == 'csv':
        df = pd.read_csv(file_path)
    elif file_extension in ['xls', 'xlsx']:
        df = pd.read_excel(file_path)
    else:
        raise ValueError("Unsupported file format. Please upload a CSV or Excel file.")
    
    # Initialize profiling results
    profiling_results = {}

    # Dimensions section
    profiling_results['dimension'] = {}

    for column in df.columns:
        # Dimension Profiling
        column_metadata = {
            'null_values': df[column].isnull().sum(),
            'datatype': str(df[column].dtype),
            'category': ''  # Placeholder for category, will fill it later
        }
        
        # Add category based on column type
        if pd.api.types.is_numeric_dtype(df[column]):
            column_metadata['category'] = 'Numerical'
        elif pd.api.types.is_categorical_dtype(df[column]) or df[column].nunique() < 10:
            column_metadata['category'] = 'Categorical'
        elif pd.api.types.is_datetime64_any_dtype(df[column]):
            column_metadata['category'] = 'Datetime'
        else:
            column_metadata['category'] = 'String'
        
        profiling_results['dimension'][column] = column_metadata

    # Measures section
    profiling_results['measures'] = {}

    for column in df.select_dtypes(include=['number', 'float64', 'int64']).columns:
        # Statistics and Aggregates for Numerical Columns
        column_statistics = {
            'count': int(df[column].count()),  # Convert to int
            'sum': float(df[column].sum()),  # Convert to float
            'variance': float(df[column].var()),  # Convert to float
            'standard_deviation': float(df[column].std()),  # Convert to float
            'mean': float(df[column].mean()),  # Convert to float
            'median': float(df[column].median()),  # Convert to float
            'mode': df[column].mode().iloc[0] if not df[column].mode().empty else None,
            'minimum': float(df[column].min()),  # Convert to float
            'maximum': float(df[column].max()),  # Convert to float
            'range': float(df[column].max() - df[column].min()),  # Convert to float
            'percentile_25': float(df[column].quantile(0.25)),  # Convert to float
            'percentile_50': float(df[column].quantile(0.50)),  # Convert to float
            'percentile_75': float(df[column].quantile(0.75)),  # Convert to float
            'skewness': float(df[column].skew()),  # Convert to float
            'kurtosis': float(df[column].kurt()),  # Convert to float
            'null_values_count': int(df[column].isnull().sum()),  # Convert to int
            'datatype': str(df[column].dtype),
            'unique_values': int(df[column].nunique()),
            'most_frequent_value': df[column].mode().iloc[0] if not df[column].mode().empty else None,
            'length': None,  # Only for object data types
            'typical_pattern': None  # Add custom pattern recognition logic here
        }
        
        profiling_results['measures'][column] = column_statistics

    # Convert the profiling results to JSON-compatible types before returning
    return json.dumps(profiling_results, indent=4, default=str)
def upload_file(request):
    if request.method == 'POST' and request.FILES.get('dataset'):
        # Get the uploaded dataset
        dataset = request.FILES['dataset']
        
        # Save the uploaded file to the server
        fs = FileSystemStorage(location=UPLOAD_DIR)
        file_path = fs.save(dataset.name, dataset)
        file_full_path = os.path.join(UPLOAD_DIR, file_path)

        try:
            # Process the uploaded file
            profiling_results = process_dataset(file_full_path)
            
            # Remove the uploaded file after processing
            os.remove(file_full_path)
            
            # Convert profiling_results to a JSON object
            profiling_json = json.loads(profiling_results)
            
            # Return the profiling results as JSON
            return render(request, 'results.html', {'results_json': profiling_json})
        except Exception as e:
            # Handle any errors in the file processing
            return HttpResponse(f"Error: {str(e)}")
    
    else:
        return HttpResponse("No file uploaded.")

